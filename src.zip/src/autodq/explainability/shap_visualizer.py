from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import shap

from autodq.explainability.models import ExplainabilityReport


class SHAPVisualizer:
    """
    Generates SHAP visualizations from cached SHAP artifacts.

    This class NEVER recomputes SHAP values.
    """

    def __init__(self, report: ExplainabilityReport):
        self.report = report

        if report.shap_artifacts is None:
            raise ValueError(
                "No SHAP artifacts available.\n"
                "Run project.explain() before visualizing SHAP."
            )

        self.artifacts = report.shap_artifacts

    # ---------------------------------------------------------

    def summary(
        self,
        save: str | None = None,
        show: bool = True,
    ):

        shap.summary_plot(
            self.artifacts.shap_values,
            self.artifacts.transformed_data,
            feature_names=self.artifacts.feature_names,
            show=False,
        )

        self._finish(save, show)

    # ---------------------------------------------------------

    def bar(
        self,
        save: str | None = None,
        show: bool = True,
    ):

        shap.summary_plot(
            self.artifacts.shap_values,
            self.artifacts.transformed_data,
            feature_names=self.artifacts.feature_names,
            plot_type="bar",
            show=False,
        )

        self._finish(save, show)

    # ---------------------------------------------------------

    def beeswarm(
        self,
        save: str | None = None,
        show: bool = True,
    ):

        shap.plots.beeswarm(
            self.artifacts.explanation,
            show=False,
        )

        self._finish(save, show)

    # ---------------------------------------------------------

    def waterfall(
        self,
        row: int = 0,
        save: str | None = None,
        show: bool = True,
    ):

        shap.plots.waterfall(
            self.artifacts.explanation[row],
            show=False,
        )

        self._finish(save, show)

    # ---------------------------------------------------------

    def dependence(
        self,
        feature: str,
        save: str | None = None,
        show: bool = True,
    ):

        shap.dependence_plot(
            feature,
            self.artifacts.shap_values,
            self.artifacts.transformed_data,
            feature_names=self.artifacts.feature_names,
            show=False,
        )

        self._finish(save, show)

    # ---------------------------------------------------------

    @staticmethod
    def _finish(
        save: str | None,
        show: bool,
    ):

        plt.tight_layout()

        if save is not None:
            Path(save).parent.mkdir(
                parents=True,
                exist_ok=True,
            )
            plt.savefig(
                save,
                dpi=300,
                bbox_inches="tight",
            )

        if show:
            plt.show()

        plt.close()